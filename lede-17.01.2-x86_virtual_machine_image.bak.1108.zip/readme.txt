=LEDE-17.01.2-x86 Virtual Image=

root password is:
123456

Make sure network card of virtual machine runs at ***bridged mode***.

The virtual machine has been set to auto obtain ip,SSH server has been enabled.
You can copy files into the virtual machine by using scp or wget.

Enjoy.

=Repo=
https://github.com/wangyu-/udp2raw-tunnel